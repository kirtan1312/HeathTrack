package com.example.CPS731;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class AddItem extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_item);
    }
}