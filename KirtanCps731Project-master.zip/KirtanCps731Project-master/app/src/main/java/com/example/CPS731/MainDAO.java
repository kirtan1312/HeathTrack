package com.example.CPS731;

import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Delete;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.Query;

import java.util.List;

@Dao
public interface MainDAO {
    @Insert()
    void insert(Calories calories);

    @Delete
    void delete(Calories calories);

    @Delete
    void reset(List<Calories> calories);

    @Query("UPDATE `Calorie table` SET value = :svalue WHERE ID = :sID")
    void update(int sID, int svalue);

    @Query("SELECT * FROM `Calorie table`")
    List<Calories> getAll();
}
